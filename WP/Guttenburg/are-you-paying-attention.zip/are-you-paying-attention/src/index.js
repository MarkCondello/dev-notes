// Wordpress adds wp to the global scope. We can access blocks.FUNCTION from that globally accessible object
wp.blocks.registerBlockType('mrc-plugin/are-you-paying-attention', {
  title: 'Are you paying attention?',
  icon: 'smiley',
  category: 'common',
  attributes: {
    skyColor: {type: "string", },
    grassColor: {type: "string", },
  },
  edit(props){
    const handleSkyColorChange = (ev) => {
      props.setAttributes({skyColor: ev.target.value})
    }
    const handleGrassColorChange = (ev) => {
      props.setAttributes({grassColor: ev.target.value})
    }
    return (
      <div>
        <input type="text" placeholder="sky colour" value={props.attributes.skyColor} onChange={handleSkyColorChange} />
        <input type="text" placeholder="grass colour" value={props.attributes.grassColor} onChange={handleGrassColorChange}/>
      </div>
    )
  },
  save(props){
    return null
  },

})
