<?php

/**
 * Plugin Name: Are you paying attention
 * Description: A plugin which generates a Guttenburg block.
 * Version: 1.0.0
 * Author: MRC
 * Author URI: https://github.com/MarkCondello
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

// Exit if accessed directly.
if (!defined('ABSPATH'))
    exit;

class AreYouPayingAttention{
  public function __construct()
  {
    add_action('init', [$this, 'adminAssets']);
  }
  public function adminAssets()
  {
    wp_register_script('areyoupayginattentionscript', plugin_dir_url(__FILE__) . '/build/index.js', ['wp-blocks']);
    register_block_type('mrc-plugin/are-you-paying-attention', [
      'editor_script' => 'areyoupayginattentionscript',
      'render_callback' => [$this, 'theHTML'], // this is where we delegate saving the block to PHP
    ]);
  }
  public function theHTML($attrs)
  {
    ob_start(); // anything thing that comes after this function is added to the buffer?>
    <h3>Today the sky is completely <?= $attrs["skyColor"] ?> and the grass is <?= $attrs["grassColor"] ?>...</h3>
    <?php
    return ob_get_clean();
  }
}
$payingAttention = new AreYouPayingAttention();