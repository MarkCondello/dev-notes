<?php
require_once __DIR__ . '/../../vendor/autoload.php';
use Lessons\Inheritance\BankAccount;

class SavingsAccount extends BankAccount{
  private $interestRate;

  public function __construct($balance, $interestRate)
	{
		parent::__construct($balance);
		$this->interestRate = $interestRate;
	}

  public function setInterestRate($interestRate)
  {
    $this->interestRate = $interestRate;
  }
  public function addInterest()
  {
      // calculate interest
      $interest = $this->interestRate * $this->getBalance();
      // deposit interest to the balance
      $this->deposit($interest);
  }

}

$savingsAccount = new SavingsAccount(100, .4);
// $savingsAccount = (new SavingsAccount())->deposit(100);
// $savingsAccount->setInterestRate(.4);
$savingsAccount->addInterest();
echo $savingsAccount->getBalance() . ' is in the balance.';

// info: https://www.phptutorial.net/php-oop/php-inheritance/
