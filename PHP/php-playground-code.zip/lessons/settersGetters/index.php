<?php

class HtmlGenerator {
	private $tag;
  private $attributes = [];

	public function __construct($tag)
	{
		$this->tag = $tag;
	}

  public function __set($key, $val) {
    if(!array_key_exists($key, $this->attributes)){
      $this->attributes[$key] = $val;
    }
  }

  public function __get($key) {
    if(array_key_exists($key, $this->attributes)){
      return $this->attributes[$key];
    }
    return null;
  }

  public function make($text = 'foo'){
    $htmlAttrs = "";
    if (count($this->attributes)) {
      foreach($this->attributes as $key=>$attribute) {
        $htmlAttrs .= "$key='{$attribute}' ";
      }
    }
    // return $htmlAttrs;
    return "<$this->tag $htmlAttrs>$text</$this->tag>";
  }

}


$divEl = new HtmlGenerator('div');
$divEl->id = "thing-id";
$divEl->class = "thing-class";

// var_dump($divEl->class);

echo $divEl->make();

// info: https://www.phptutorial.net/php-oop/php-magic-methods/
