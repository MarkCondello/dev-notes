<?php
require_once __DIR__ . '/../../vendor/autoload.php';
use Lessons\Inheritance\BankAccount;

class User {
  public $thing;
  public function FunctionName() {}
}

if (class_exists('User')){
  echo 'The class User exists.';
} else {
  echo 'The class User does not exist.';
}
echo '</br>';
$myUser = new User;

if (method_exists($myUser, 'FunctionName')) {
  echo 'The FunctionName method exists on the $myUser object.';
} else {
  echo 'The FunctionName method does not exist on the $myUser object.';
}

if  (property_exists(User::class, 'thing')) {
  echo 'The $thing property exists on the User class.';
} else {
  echo 'The $thing property does not exists on the User class.';
}


if (class_exists('Lessons\Inheritance\BankAccount')){
  echo 'The class BankAccount exists.';
} else {
  echo 'The class BankAccount does not exist.';
}
echo '</br>';

// if (method_exists(BankAccount::class, 'deposit')) { OR
if (method_exists('Lessons\Inheritance\BankAccount', 'deposit')) {
  echo 'The deposit method exists on the class BankAccount.';
} else {
  echo 'The deposit method does not exist on the class BankAccount.';
}


