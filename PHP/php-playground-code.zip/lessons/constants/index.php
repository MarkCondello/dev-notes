
<?php

abstract class Model
{
  protected const TABLE_NAME = ''; // consts can only be called by using static::

  public static function all()
  {
    return 'SELECT * FROM ' . static::TABLE_NAME;
  }
}

class User extends Model
{
  protected const TABLE_NAME = 'users';
}

class Role extends Model
{
  const TABLE_NAME = 'roles';
}

echo User::all(); // SELECT * FROM users;
echo '<br/>';

echo Role::TABLE_NAME; // we can get the value of a const from a class when it is not private or protected
echo '<br/>';
echo Role::all(); // SELECT * FROM roles;


// info: https://www.phptutorial.net/php-oop/php-class-constants/
