
<?php
require_once __DIR__ . '/../../vendor/autoload.php';
use Lessons\StaticMethodsAndProps\App;

$app = App::get();
$app->setProp(123 . 'abc@foo');
$app1 = App::get();
var_dump($app1);
$app1->bootstrap();


// info: https://www.phptutorial.net/php-oop/php-static-methods/
