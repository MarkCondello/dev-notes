<?php

namespace Lessons\StaticMethodsAndProps;

class App
{
	private static $app = null;
  public $prop = null;

	private function __construct() // prevents instantiaton without static get() call
	{}

	public static function get() : App
	{
		if (!self::$app) {
			self::$app = new App();
		}

		return self::$app;
	}

  public function setProp($val = null)
  {
    $this->prop = $val;
  }

	public function bootstrap(): void
	{
		echo 'App is bootstrapping...';
	}
}