<?php
include './Dumper.php';

class Logger extends Dumper{
  public function dump($data)
  {
    return 'LOGGER DUMP: <br/><pre>' . var_dump($data) . '</pre>';
  }
}
$logger = new Logger();
echo $logger->dump(['foo' => 'BARR']);

$logger->test("something");

// info: https://www.phptutorial.net/php-oop/php-abstract-class/
