<?php
abstract class Dumper
{
  // abstract public $name; //cant define properties as abstract
	abstract public function dump($data); // abstract methods can not have a body

  public static function test($param = '')
  {
    echo "TEST: $param";
  }

}