<?php

class Robot
{
	public function greet()
	{
		return 'Hello!';
	}

  final public function id() // can't be over written by child classes
	{
		return uniqid();
	}
}

