<?php
require './BankAccount.php';

class CheckingAccount extends BankAccount
{
	private $minBalance;

	public function __construct($amount, $minBalance)
	{
		if ($amount > 0 && $amount >= $minBalance) {
			parent::__construct($amount);
			$this->minBalance = $minBalance;
		} else {
			throw new InvalidArgumentException('amount must be more than zero and higher than the minimum balance');
		}
	}

	public function withdraw($amount)
	{
		$canWithdraw = $amount > 0 && $this->getBalance() - $amount > $this->minBalance;
		if ($canWithdraw) {
			parent::withdraw($amount);
			return true;
		}
		return false;
	}
}
$checkAccount = new CheckingAccount(200, 5);
echo $checkAccount->withdraw(1000) ? 'funds are available' : 'no available funds';

// require './Robot.php';

// class Android extends Robot {
//   function greet() {
//     $greeting = parent::greet();
//     return $greeting . ' from Andriod..';
//   }
//   // public function id() // can't be over written by child classes
// 	// {
// 	// 	return 'ANDROID: ' . uniqid();
// 	// }
// }

// $samsung = new Android();
// echo $samsung->id();

// info: https://www.phptutorial.net/php-oop/php-override-method/