<?php
namespace Lessons\Traits;
use Lessons\Traits\Logger;

class BankAccount
{
  use Logger;
  private $balance;
	private $accountNumber;

	public function __construct($accountNumber, $balance = 0)
	{
		$this->accountNumber = $accountNumber;
    $this->balance = number_format($balance, 2);
    $this->log("A new $accountNumber bank account created with the balance of \$$this->balance.");
  }
  public function getBalance()
  {
    return $this->balance;
  }

  public function deposit($amount)
  {
    if ($amount > 0) {
      $this->balance += $amount;
    }
    return $this;
  }
}