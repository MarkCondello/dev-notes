<?php
namespace Lessons\Traits;

use Lessons\Traits\Logger;

class User
{
	use Logger;

	public function __construct()
	{
		$this->log('A new user was created.');
	}
}