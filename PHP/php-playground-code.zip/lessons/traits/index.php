<?php
require_once __DIR__ . '/../../vendor/autoload.php';
use Lessons\Traits\BankAccount;
use Lessons\Traits\User;

$bankAccount = new BankAccount(1234, 1000);
$user = new User();

// info: https://www.phptutorial.net/php-oop/php-traits/