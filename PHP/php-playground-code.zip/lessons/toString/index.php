<?php

class BankAccount
{
	private $accountNumber;

	private $balance;

	public function __construct(
		$accountNumber,
		$balance
	) {
		$this->accountNumber = $accountNumber;
		$this->balance = $balance;
	}

	public function __toString() // without a __toString method, a fatal error would occur.
	{
		return "Bank Account: $this->accountNumber. Balance: $$this->balance";
	}
}


$account = new BankAccount('123456789', 100);
echo $account;

//Info: https://www.phptutorial.net/php-oop/php-__tostring/

// The __call() method is useful when the method being called is not defined. We can catch that call and process it how we like: https://www.phptutorial.net/php-oop/php-__call/
// __callStatic() is almost the same thing but is used for static functions instead: https://www.phptutorial.net/php-oop/php-__callstatic/