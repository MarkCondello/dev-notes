<?php
class Customer
{
	protected $name; // changing this property to private will make it unaccessible

	public function __construct($name)
	{
		$this->name = $name;
	}

	protected function format()
	{
		return ucwords($this->name);
	}

	public function getName()
	{
		return $this->format($this->name);
	}

  protected function myProtectedMethod() {
    echo "This is the parent protected method.";
  }
}