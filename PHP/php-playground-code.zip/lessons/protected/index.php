<?php

//The protected properties and methods can be accessed from the inside of the class and any class that extends the class.

require './Customer.php';

class VipCustomer extends Customer
{

  // public function format(){ // this works, but adding it to protected does not
  //   return $this->name . ' overritten yo..';
  // } 
  public function formattedName()
	{
		return $this->format();
	}

  protected function format()
	{
		return ucwords($this->name) . ' from the VIP CLASS yawl.';
	}

  protected function myProtectedMethod() {
    echo "This is the child protected method, overriding the parent method.";
  }

  public function myPubliclyExposedProtectedMethod(){
    return $this->myProtectedMethod();
  }
}
// protected properties and methods can not be accessed outside extended class or instances of a class.

$vip = new VipCustomer('lower caste person');
// echo $vip->format();
echo $vip->formattedName();

echo '<br/>';
$vip->myPubliclyExposedProtectedMethod();
// echo $vip->getName();


// info: https://www.phptutorial.net/php-oop/php-protected/