<?php
require __DIR__ . '/vendor/autoload.php';

use Cocur\Slugify\Slugify;
$slugify = new Slugify();
echo $slugify->slugify('Hello World! The sky is blue, and the grass is green...'); // hello-world