class Character {
  constructor(powers, strength, iq) {
    this.powers = powers;
    this.strength = strength;
    this.iq = iq;
  }
}

class Archer extends Character {}
class Mage extends Character {}
class Thief extends Character {}
class Warrior extends Character {}

class Profile {
  constructor(name, email = '') {
    this.id = Math.floor(Math.random() * 100)
    this.name = name
    this.email = email
    this.character = null
  }
  createCharacter(classType) {
    switch (classType) {
      case 'archer': return this.character = new Archer()
      case 'mage': return this.character = new Mage('Magic', 75, 115)
      case 'thief': return this.character = new Thief()
      case 'warrior': return this.character = new Warrior()
      default:
        throw new Error(`Invalid class type "${classType}". Choose another, [archer, mage, thief, warrior]`)
    }
  }
  syncProfileContacts(anotherProfile) {
    //do something to inherit another profile's contacts
  }
  setName(name){
    this.name = name
  }
  setEmail(email){
    this.email = email
  }
}

class Game {
  constructor() {
    this.users = {}
  }
  createUser(name) {
    const user = new Profile(name)
    this.users[user.id] = user
    return user
  }
}
const game = new Game()
const bobsProfile = game.createUser('bob')
const bobsMage = bobsProfile.createCharacter('mage')

console.log({game, bobsMage})

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random