class Character {
	constructor(powers = null, strength = 0, iq = 50) {
		this.powers = powers
		this.strength = strength
		this.iq = iq
		this.equipment= null
	}
	useEquipment(equipment){
		this.equipment = equipment
	}
}

class Equipment {
	constructor(name) {
		this.name = name
	}
}

class Archer extends Character {
	// constructor({powers, strength, iq}){
	//   super()
	//   this.powers = powers;
	//   this.strength = strength;
	//   this.iq = iq;
	//   // this.weapon = 'Bow & Arrow';
	//  }
}
class Mage extends Character {
	// constructor({powers, strength, iq}){
	//   super()
	//   this.powers = powers;
	//   this.strength = strength;
	//   this.iq = iq;
	//   // this.weapon = 'Staff';
	//  }

}
class Thief extends Character {}
class Shaman extends Character {}
class Warrior extends Character {}

class CharacterClassCreator {
	async applyMembershipCode() {
		// return fetch('https://SOME_ENDPOINT')
		// .then(resp => resp.json())
		// .then(data => data)
		return { equipment: [{ type: 'ore'}]}
	}
	async create(profile, classType) {
		const creatorMap = {
			archer: {
				Class: Archer
			},
			mage: {
				Class: Mage
			},
			shaman: {
				Class: Shaman
			},
			thief: {
				Class: Thief
			},
			warrior: {
				Class: Warrior
			},
		}
		let character
		let starterWeapon
		if(creatorMap[classType]) {
			const {Class, membership} = creatorMap[classType]
			character = new Class()
			if (character instanceof Archer) {
				starterWeapon = new Equipment('crossbow')
			} else if (character instanceof Mage) {
				starterWeapon = new Equipment('staff')
			} else if (character instanceof Shaman) {
				starterWeapon = new Equipment('claw')
			} else if (character instanceof Thief) {
				starterWeapon = [new Equipment('dagger'), new Equipment('dagger')]
			} else if (character instanceof Warrior) {
				starterWeapon = new Equipment('sword')
			}

			character.useEquipment(starterWeapon)
			if (profile.code && typeof profile.code === 'number') {
				const { equipments: _equipments_ } = await this.applyMembershipCode(
					profile.code,
				)
				// There are equipments provided in addition to the starter weapon.
				// This is most likely the result of the user paying for extra stuff
				_equipments_.forEach((equipment) => {
					// For thief class that uses duo daggers
					if (Array.isArray(equipment)) {
						character.useEquipment(equipment[0])
						character.useEquipment(equipment[1])
					} else {
						character.useEquipment(equipment)
					}
					if (membership) {
						if (membership.status === 'gold') {
							// They bought a gold membership. Ensure we apply any starter equipment enhancents they bought with their membership at checkout when they created a new account
							if (membership.accessories) {
								membership.accessories.forEach(({ accessory }) => {
									if (accessory.type === 'ore') {
										// Each ore has an 80% chance of increasing the strength of some weapon when using some enhancer
										const { succeeded, equipment } = this.applyEnhancement(
											starterWeapon,
											accessory,
										)
										if (succeeded) starterWeapon = equipment
									} else if (accessory.type === 'fun-wear') {
										// They also bought something fancy just to feel really cool to their online friends
										character.useEquipment(new Equipment(accessory.name))
									}
								})
							}
						}
					}
				})
      
			}
		}
		return character
	}
}

class Profile {
	constructor(name, email = '') {
		this.id = Math.floor(Math.random() * 100)
		this.name = name
		this.email = email
		this.character = null
	}
	setCharacter(character){
		this.character = character
	}
	syncProfileContacts() {
		//do something to inherit another profile's contacts
	}
	setName(name){
		this.name = name
	}
	setEmail(email){
		this.email = email
	}
}

class Game {
	constructor() {
		this.users = {}
	}
	createUser(name, email = '') {
		const user = new Profile(name, email)
		this.users[user.id] = user
		return user
	}

	//createBUilding
	//createTerrain
}
const game = new Game()
const characterClassCreator  = new CharacterClassCreator()

// const MageChar = characterCreator.create('mage', { powers : 'Magic', strength : 30, iq : 150})
// const bobsProfile = game.createUser('Bob', 'b@b.com', )
// bobsProfile.setCharacter(MageChar)
// console.log({bobsProfile } )


const janesProfile = game.createUser('Jane', 'j@d.com', )
const ArcherChar = characterClassCreator.create(janesProfile, 'mage')
janesProfile.setCharacter(ArcherChar)
console.log({ janesProfile, JanesChar: janesProfile.character } )
// console.log({game } )
// console.log(' Users: ', game.users )

// https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random