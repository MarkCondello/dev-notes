"use strict";
let addValsBtn = document.querySelector('.addValsBtn') || document;
let valOne = document.getElementsByName("valOne")[0];
let valTwo = document.getElementsByName("valTwo")[0];
function my_sum(a, b) {
    return a + b;
}
let ba = 5;
let ab = 43;
let sum = my_sum(+ba, +ab);
console.log({ sum });
addValsBtn.addEventListener("click", () => {
    console.log("reached click");
    let vals = my_sum(+valOne.value, +valTwo.value);
    console.log({ vals });
    return vals;
});
//# sourceMappingURL=index.js.map