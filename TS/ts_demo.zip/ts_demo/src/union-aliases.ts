
// function combines(input1: number | string, input2: number | string, resultConversion: string){
//     let result = null;
//     if(typeof input1 === 'number' && typeof input2 === 'number' || resultConversion === 'as-number'){
//          result = +input1 + +input2;
//     } else {
//         result = input1.toString() + input2.toString();
//     }
//     return result;
// }

// function combines(
//         input1: number | string, 
//         input2: number | string, 
//         resultConversion: 'as-number' | 'as-string' // type literal
//     ){
//     let result = null;
//     if(typeof input1 === 'number' && typeof input2 === 'number' || resultConversion === 'as-number'){
//          result = +input1 + +input2;
//     } else {
//         result = input1.toString() + input2.toString();
//     }
//     return result;
// }
type Combinables = number | string;
type ResultConversion = 'as-number' | 'as-string';

function combines(
    input1: Combinables, 
    input2: Combinables, 
    resultConversion: ResultConversion // type literal
){
let result = null;
if(typeof input1 === 'number' && typeof input2 === 'number' || resultConversion === 'as-number'){
     result = +input1 + +input2;
} else {
    result = input1.toString() + input2.toString();
}
return result;
}

let combinedAges = combines(30, 26, 'as-number');
console.log({combinedAges})

let combinedStringAges = combines('30', '26', 'as-number');
console.log({combinedStringAges})

let combinedNames = combines('Anna', 'Blick', 'as-string');
console.log({combinedNames})
