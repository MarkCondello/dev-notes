function add(n1: number, n2: number) {
    return n1 + n2;
}

function printRes(num: number):void { // this function returns no value
    console.log('Result: '+ num);
}
printRes(666);
function printNull(num: number):undefined { // this function returns undefined
    return;
}
function addAndHanlde(n1: number, n2: number, cb: (num: number) => number) {
    let result = n1 + n2;
    return cb(result);
}
let resp = addAndHanlde(11,22, (res)=> { 
    return res + 33;
});
console.log({resp}); 

 // let combineValues: Function; // A typescript type which expects the variable to be assigned to a function
let combineValues: (a: number, b: number) => number; // A typescript function type with parameter types defined
combineValues = add;
console.log(combineValues(8,8))
