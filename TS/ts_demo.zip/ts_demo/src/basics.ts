function my_sums(a: number, b: number, showresult: boolean, resultPhrase: string){
    // if(typeof a !== 'number' || typeof b !== 'number'){
    //     throw new Error("Wrong paramater type");
    // }
    let result = a + b;
    if (showresult){
        console.log(`${resultPhrase}${result}`);   
    } else {
        return result;
    }
}

const a = 9.5; //consts define the type explicitly
let b = 43;
let printResult = true;
let phrase = "My Sum is: ";
let summ = my_sums(a, b, printResult, phrase);
 