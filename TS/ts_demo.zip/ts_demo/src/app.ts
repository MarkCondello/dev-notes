// https://medium.com/swlh/call-apply-bind-javascript-methods-7d96a73816e8#id_token=eyJhbGciOiJSUzI1NiIsImtpZCI6IjAzMmIyZWYzZDJjMjgwNjE1N2Y4YTliOWY0ZWY3Nzk4MzRmODVhZGEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJuYmYiOjE2Mzc0ODYyNTAsImF1ZCI6IjIxNjI5NjAzNTgzNC1rMWs2cWUwNjBzMnRwMmEyamFtNGxqZGNtczAwc3R0Zy5hcHBzLmdvb2dsZXVzZXJjb250ZW50LmNvbSIsInN1YiI6IjEwMzIyMzAyNDMyNzEyOTExNTcxMSIsImVtYWlsIjoiY29uZGVsbG9tYXJrQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhenAiOiIyMTYyOTYwMzU4MzQtazFrNnFlMDYwczJ0cDJhMmphbTRsamRjbXMwMHN0dGcuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJuYW1lIjoiTWFyayBDb25kZWxsbyIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS0vQU9oMTRHaTBlOVZjQnBmY1hsbm1peEVOUGdPU0s5eElqUkhIWHVaTHg3MDkwQT1zOTYtYyIsImdpdmVuX25hbWUiOiJNYXJrIiwiZmFtaWx5X25hbWUiOiJDb25kZWxsbyIsImlhdCI6MTYzNzQ4NjU1MCwiZXhwIjoxNjM3NDkwMTUwLCJqdGkiOiIyYTQ0OWQzYjNhMjNhOGI1OTU4MzZlZjMyMDU5MGJlNmM0MDRlMGRlIn0.eqpiXR1y0HQcLGzLdtSJnQJlAQMmaX2RKDOCwZuQlXo_NLcWvuo_UXJKWPQv2s0K8YUZSvm-Wx6qxxX04cy47MuxjEkFKJwYmcLhihmLHEt_-Ksvf-JPKx1Hy775EJ9buGib05v8Pt9q6UqiCj5FJbOElqsKo329pGooViq6BD3P7A7Kd2u4asVaovGMIPBKkmgRNuW17RQ0t4Qd7MGF52tuumMUHyqWKbKk5Oz0AO50nV-oLVs4QLQwVpNgeDbuigEcCoudwrCM-ANH4ioAMhojBpYSAis0cO0Qqs-h6I6V-k6s2lvmbrlVafXhP7Jn0JNSGnWg0zlnPurOCdXLxQ
let increment = function(this: {age: number, name: string}, val: number, surname: string): object { 
    this.age += val;
    this.name += ' ' + surname;
    return this;
}

let personi = { age: 39, name: "Mark", }

increment.call(personi, 10, 'Condellomightus');
increment.apply(personi, [1, 'CondellosCollos']);

let boundIncrementWPersoni = increment.bind(personi, 5, ' Barr');
boundIncrementWPersoni();
console.log({...personi});

let msg = "sending data...";
console.log(msg);
 
let btn = document.querySelector('button');

let clickHandler = (msg: string) => console.log("Clicked " + msg)
if (btn){
    btn.addEventListener('click',  clickHandler.bind(null, "mofo..."));
}

class Url {
    endpoint: string;
    key: string;
    url: string;
    constructor(key: string, forecast:boolean = false){
        this.endpoint = "https://someapi/v1/json/";
        this.key = key;
        this.url = '';
        if(forecast){
            this.getForecastUrl();
        } else {
            this.getTodayUrl();
        }
    }
    getForecastUrl(){
        this.url = `${this.endpoint}forecast&key${this.key}`;
    }
    getTodayUrl(){
        this.url = `${this.endpoint}current&key${this.key}`;
    }
}

let current = new Url("12345", true).url;
console.log({current})