// we can define what properties make up an object similar to that below:
let personA: {
    name: string;
    age: number;
    hobbies: (string|number|object)[];//an array can have string,number or object values
    role: [number, string]; // tuple with specific types
} = {
    name: "Maximillian",
    age: 30,
    hobbies: ['sports', 'cooking', ['ggf', 123]],
    role: [2, 'author'],
};
// a key type pair is generated in TS eg name: string; age: integer
//person.role = [0, 'admin']; //push operations do not adhere to tuple validations

enum Role {
    ADMIN = 4, READ_ONLY, VISITOR
}; //enums are like constants which have index values added to them, strings can also be added, by default they are 0 based

let person = {
    name: "Maximillian",
    age: 30,
    hobbies: ['sports', 'cooking',  ],
    role: Role.ADMIN, //4
};

let favActivities: string[];
favActivities = ['test', '123'];

console.log({person});